var classParma__Polyhedra__Library_1_1Throwable =
[
    [ "~Throwable", "classParma__Polyhedra__Library_1_1Throwable.html#a5024cc2b142473f5f733a8808cb09162", null ],
    [ "throw_me", "classParma__Polyhedra__Library_1_1Throwable.html#a14c081beabe1e165b1dc44b2a84b6c2b", null ]
];