var structParma__Polyhedra__Library_1_1H79__Certificate_1_1Compare =
[
    [ "operator()", "structParma__Polyhedra__Library_1_1H79__Certificate_1_1Compare.html#abf5e694ab674c48a452893f021986318", null ]
];