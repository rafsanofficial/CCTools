var namespaces =
[
    [ "Parma_Polyhedra_Library", "namespaceParma__Polyhedra__Library.html", "namespaceParma__Polyhedra__Library" ],
    [ "std", "namespacestd.html", null ]
];