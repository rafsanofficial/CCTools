var structParma__Polyhedra__Library_1_1BHRZ03__Certificate_1_1Compare =
[
    [ "operator()", "structParma__Polyhedra__Library_1_1BHRZ03__Certificate_1_1Compare.html#a98c515b16e12424b273eaff073b31f3b", null ]
];