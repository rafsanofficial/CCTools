var classParma__Polyhedra__Library_1_1Shape__Preserving__Reduction =
[
    [ "Shape_Preserving_Reduction", "classParma__Polyhedra__Library_1_1Shape__Preserving__Reduction.html#aaaf6dc9a305149db551f3dff63d7e6f4", null ],
    [ "~Shape_Preserving_Reduction", "classParma__Polyhedra__Library_1_1Shape__Preserving__Reduction.html#aa8bb2afcbf530af32dd1251242a480e9", null ],
    [ "product_reduce", "classParma__Polyhedra__Library_1_1Shape__Preserving__Reduction.html#a8411ac9c6855778aa3f0f47a66bdfff6", null ]
];