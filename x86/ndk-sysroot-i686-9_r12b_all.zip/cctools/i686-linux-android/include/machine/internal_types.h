/* $OpenBSD: internal_types.h,v 1.1 2002/04/24 21:53:11 espie Exp $ */
/* Public domain */
#ifndef _MACHINE_INTERNAL_TYPES_H_
#define _MACHINE_INTERNAL_TYPES_H_

#endif
